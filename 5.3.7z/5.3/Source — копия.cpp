#include "Matrix.h"
#include <iostream>
int main()
{
    int choise;
    int a = 0;
    while (a == 0)
    {
        std::cout << "What do you wanna do?\n1. Trace\n2. Input/output\n3. Sum matr\n4. Matr_mult\n5. -Matr\n6. -*Matr\n7. �����\n";
        std::cin >> choise;
        switch (choise)
        {
        case 1:
        {
            Matrix m1;
            std::cin >> m1;
            std::cout << m1.trace() << '\n';
        }
        case 2:
        {
            Matrix m1;
            std::cin >> m1;
            std::cout << m1 << '\n';
        }
        case 3:
        {
            Matrix m1, m2;
            std::cin >> m1;
            std::cin >> m2;
            m1 + m2;
            std::cout << '\n';
        }
        case 4:
        {
            Matrix m1;
            int k;
            std::cin >> m1 >> k;
            m1* k;
            std::cout << m1;
        }
        case 5:
        {
            Matrix m1, m2;
            std::cin >> m1;
            std::cin >> m2;
            m1 - m2;
            std::cout << '\n';
        }
        case 6:
        {
            Matrix m1;
            std::cin >> m1;
            -m1;
            std::cout << '\n';
        }
        default:return 0;
        }
    }
}