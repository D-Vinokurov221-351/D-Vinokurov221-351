#include "Matrix.h"
#include <iostream>

Matrix::Matrix()
{
	input();
}
Matrix::Matrix(int row, int col)
{
	input(row, col);
}
Matrix::Matrix(int row, int col, double* arr)
{
	input(row, col, arr);
}
Matrix::Matrix(int size)
{
	input(size);
}
Matrix::Matrix(int size, double* arr)
{
	input(size, arr);
}
Matrix::Matrix(const Matrix& Matrix1)
{
    if (elem != nullptr)
		delete[]elem;
	this->size_col = Matrix1.size_col;
	this->size_row = Matrix1.size_row;
	elem = new double[size_col * size_row];
	for (int i = 0; i < size_col * size_row; i++) this->elem[i] = Matrix1.elem[i];
}
Matrix::~Matrix()
{
	if (elem != nullptr)
		delete[]elem;
}

void Matrix::input(int row, int col)
{
	size_col = col;
	size_row = row;
	elem = new double[col * row];
	for (int i = 0; i < col * row; i++)
	{
		std::cin >> elem[i];
	}
}
void Matrix::input(int row, int col, double* arr)
{
	size_col = col;
	size_row = row;
	elem = new double[col * row];
	for (int i = 0; i < col * row; i++)
	{
		elem[i] = arr[i];
	}
}

void Matrix::input(int row, double num , int col)
{
	size_col = col;
	size_row = row;
	elem = new double[col * row];
	for (int i = 0; i < col * row; i++)
	{
		elem[i] = num;
	}
}

void Matrix::sum(int i, double num)
{
    elem[i] += num;
}

void Matrix::input(int size)
{
	input(1, size);
}
void Matrix::input(int size, double* arr)
{
	size_col = size;
	size_row = 1;
	elem = new double[size];
	for (int i = 0; i < size; i++)
	{
		elem[i] = arr[i];
	}
}
void Matrix::input()
{
	std::cin >> size_col >> size_row;
	elem = new double(size_row * size_col);
	for (int i = 0; i < size_row * size_col; i++)
	{
		std::cin >> elem[i];
	}
}

void Matrix::output()
{
	for (int i = 0; i < size_row; i++)
	{
		for (int j = 0; j < size_col; j++)
		{
			std::cout << elem[i * size_col + j] << " ";
		}
		std::cout << std::endl;
	}
}
bool Matrix::sum_matrix(const Matrix& Matrix1)
{
	if ((size_col != Matrix1.size_col) || (size_row != Matrix1.size_row)) return false;
	for (int i = 0; i < this->size_col * this->size_row; i++)
	{
		elem[i] = this->elem[i] + Matrix1.elem[i];
	}
	return true;
}
bool Matrix::sum_matrix(const Matrix& Matrix1, int size)
{
    sum_matrix(Matrix1);
	return true;
}
void Matrix::mult_number(int number)
{
	for (int i = 0; i < this->size_col * this->size_row; i++)
	{
		elem[i] = elem[i]*number;
	}
}
bool Matrix::mult_matrix(const Matrix& Matrix1)
{
	if ((this->size_col == Matrix1.size_row))
	{
		for (int i = 0; i < size_row; i++)
		{
			for (int j = 0; j < size_col; j++)
			{
				long sum = 0;
				for (int n = 0; n < size_col; n ++)
				{
					sum += elem[n * size_row + j] * Matrix1.elem[Matrix1.size_col*j + n];
				}
				elem[i * size_col + j] = sum;
			}
		}
	}
	else 
	{
		return false;
	}
}
bool Matrix::mult_matrix(const Matrix& Matrix1, int size)
{
	return mult_matrix(Matrix1);
}
double Matrix::get_elem(int i, int j)
{ 
	return elem[i * size_col + j]; 
}
double Matrix::get_elem(int i)
{ 
	return elem[i]; 
}
int Matrix::get_row()
{ 
	return size_row; 
}
int Matrix::get_col()
{ 
	return size_col; 
}
double Matrix::trace()
{
	double trace = 0;
	for (int i = 0; i < this->size_col; i++) {
		trace += this->elem[i*size_col+i];
	}
	return trace;
}
double Matrix::tr()
{
	return trace(); 
}

void Matrix::operator+=(const Matrix& Matrix1)
{
	sum_matrix(Matrix1);
}

void Matrix::operator-=(const Matrix& Matrix1)
{
	for (int i = 0; i < Matrix1.size_row * Matrix1.size_col; i++) {
		this->elem[i] -= Matrix1.elem[i];
	}
}

void Matrix::operator=(Matrix& Matrix1)
{
	if (elem != nullptr)
		delete[]elem;
	elem = new double[Matrix1.size_col * Matrix1.size_row];
	this->size_col = Matrix1.size_col;
	this->size_row = Matrix1.size_row;
	for (int i = 0; i < Matrix1.size_col * Matrix1.size_row; i++) this->elem[i] = Matrix1.elem[i];
}

void Matrix::operator+(Matrix& Matrix1)
{
	Matrix out;
	out = Matrix1;
	for (int i = 0; i < Matrix1.size_col * 3; i++)
	{
		out.elem[i] = this->elem[i] + Matrix1.elem[i];
	}
	std::cout << out;
}

void Matrix::operator-(Matrix& Matrix1)
{
	Matrix out;
	out = Matrix1;
	for (int i = 0; i < Matrix1.size_col * Matrix1.size_row; i++)
	{
		out.elem[i] = this->elem[i] - Matrix1.elem[i];
	}
	std::cout << out;
}

void operator-(Matrix& Matrix2)
{
	for (int i = 0; i < Matrix2.size_col * Matrix2.size_row; i++) Matrix2.elem[i] *= -1;
	Matrix2.output();
}

void Matrix::operator*(double num)
{
	for (int i = 0; i < size_row * size_col; i++) elem[i] *= num;
}

Matrix operator*(Matrix& Matrix1 , Matrix& Matrix2)
{
    Matrix out;
	if ((Matrix1.get_col() == Matrix2.get_row()))
	{
		
		out.input(Matrix1.get_col(), 0. ,Matrix1.get_row());
		for (int i = 0; i < Matrix1.get_row(); i++) {
			for (int j = 0; j < Matrix1.get_col(); j++) {
				for (int k = 0; k < Matrix1.get_col(); k++) {
					out.sum(i * Matrix1.get_col() + j, Matrix1.get_elem(i * Matrix1.get_col() + k) * Matrix2.get_elem(k * Matrix2.get_col() + j));
				}
			}
		}
		out.output();
	}
	return out;
}

std::istream& operator>>(std::istream& input, Matrix& Matrix1)
{
	int size;
	input >> size;
	Matrix1.input(size);
	return input;
}

std::ostream& operator<<(std::ostream& out, const Matrix& Matrix1)
{
	for (int i = 0; i < Matrix1.size_col; i++) {
		for (int j = 0; j < Matrix1.size_row; j++) {
			out << Matrix1.elem[i* Matrix1.size_row + j] << " ";
		}
		out << '\n';
	}
	return out;
}