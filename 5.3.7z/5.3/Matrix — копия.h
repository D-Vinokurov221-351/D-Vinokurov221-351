#pragma once
#include <iostream>
class Matrix
{
private:
	int size_col, size_row;
	double* elem;
public:
	Matrix();
	Matrix(int row, int col);
	Matrix(int row, int col, double* arr);
	Matrix(int size);
	Matrix(int size, double* arr);
	Matrix(const Matrix& Matrix1);
	~Matrix();

	void input(int row, int col);
	void input(int row, int col, double* arr);
	void input(int row, double num, int col);
	void input(int size);
	void input(int size, double* arr);
	void input();
	void output();
	void sum(int i, double num);
	bool sum_matrix(const Matrix& temp);
	bool sum_matrix(const Matrix& temp, int size); 
	void mult_number(int number);
	bool mult_matrix(const Matrix& temp);
	bool mult_matrix(const Matrix& temp, int size);
	double get_elem(int i, int j) ;
	double get_elem(int i);
	int get_row() ;
	int get_col() ;
	double trace();
	double tr();

	void operator+=(const Matrix& Matrix1);
	void operator=(Matrix& Matrix1);
	void operator+(Matrix& Matrix1);
	void operator-(Matrix& Matrix1);
	void operator*(double k);
	void operator-=(const Matrix& Matrix1);
	Matrix operator*(Matrix& Matrix2);

	friend void operator-(Matrix& Matrix2);
	friend std::istream& operator>>(std::istream& input, Matrix& Matrix1);
	friend std::ostream& operator<<(std::ostream& out, const Matrix& Matrix1);
};

