#include "Matrix.h"
#include <iostream>
Matrix()
{
	input();
}
Matrix(int row, int col)
{
	input(row, col);
}
Matrix(int row, int col, double* arr)
{
	input(row, col, arr);
}
Matrix(int size)
{
	input(size);
}
Matrix(int size, double* arr)
{
	input(size, arr);
}
Matrix(const Matrix& Matrix1)
{
	int row = Matrix1.size_row;
	int col = Matrix1.size_col;
	input(row, col, Matrix1);
}
~Matrix()
{
	if (elem != nullptr)
		delete[]elem;
	return 0;
}

void Matrix::input(int row, int col)
{
	size_col = col;
	size_row = row;
	elem = new double[col * row];
	for (int i = 0; i < col * row; i++)
	{
		cin >> elem[i];
	}
}
void Matrix::input(int row, int col, double* arr)
{
	size_col = col;
	size_row = row;
	elem = new double[col * row];
	for (int i = 0; i < col * row; i++)
	{
		elem[i] = arr[i];
	}
}
void Matrix::input(int size)
{
	input(1, size);
}
void Matrix::input(int size, double* arr)
{
	size_col = col;
	size_row = row;
	elem = new double[col * row];
	for (int i = 0; i < col * row; i++)
	{
		elem[i] = arr[i];
	}
}
void Matrix::input()
{
	cin >> size_col >> size_row;
	elem = new double(size_row * size_col);
	for (int i = 0; i < size_row * size_col; i++)
	{
		cin >> elem(i);
	}
}

void Matrix::output()
{
	for (int i = 0; i < size_row; i++)
	{
		for (int j = 0; j < size_col; j++)
		{
			elem[i * size_col + j] << " ";
		}
		cout << endl;
	}
}
bool Matrix::sum_matrix(const Matrix& Matrix1)
{
	if ((size_col != Matrix1.size_col) || (size_row != Matrix1.size_row)) return false;
	for (int i = 0; i < this->size_col * this->size_row; i++)
	{
		elem[i] = this->elem[i] + Matrix1.elem[i];
	}
	return true;
}
bool Matrix::sum_matrix(const Matrix& Matrix1, int size)
{
	return sum_matrix(const Matrix1);
}
void Matrix::mult_number(int number)
{
	int num;
	cin << num;
	for (int i = 0; i < this->size_col * this->size_row; i++)
	{
		elem[i] = elem[i]*num;
	}
}
bool Matrix::mult_matrix(const Matrix& Matrix1)
{
	if ((this->size_col == Matrix1.size_row))
	{
		for (int i = 0; i < size_row; i++)
		{
			for (int j = 0; j < size_col; j++)
			{
				long sum = 0;
				for (int n = 0; n < size_col; n ++)
				{
					sum += elem[n * size_row + j] * Matrix1.elem[Matrix1.size_col*j + n];
				}
				elem[i * size_col + j] = sum;
			}
		}
	}
	else 
	{
		return false;
	}
}
bool Matrix::mult_matrix(const Matrix& Matrix1, int size)
{
	return mult_matrix(Matrix1);
}
double Matrix::get_elem(int i, int j)
{ 
	return elem[i * size_col + j]; 
}
int Matrix::get_row()
{ 
	return size_row; 
}
int Matrix::get_col()
{ 
	return size_col; 
}
double Matrix::trase()
{
	double trase = 0;
	for (int i = 0; i < this->size_col; i++) {
		trase += this->elem[i*size_col+i];
	}
	return trase;
}
double Matrix::tr()
{
	return trace(); 
}

void Matrix::operator+=(const Matrix& Matrix1)
{
	sum_matrix(Matrix1);
}

void Matrix::operator-=(const Matrix& Matrix1)
{
	for (int i = 0; i < Matrix1.size_row * Matrix1.size_col; i++) {
		this->elem[i] -= Matrix1.elem[i];
	}
}

void Matrix::operator=(const Matrix& Matrix1)
{
	this->input(Matrix1.size_row * Matrix1.size_col, Matrix1);
}

void Matrix::operator+(Matrix& Matrix1)
{
	Matrix out;
	out = right;
	for (int i = 0; i < right.cols * 3; i++)
	{
		out.elem[i] = this->elem[i] + Matrix1.elem[i];
	}
	std::cout << out;
}

void Matrix::operator-(Matrix& Matrix1)
{
	Matrix out;
	out = Matrix1;
	for (int i = 0; i < Matrix1.size_col * 3; i++)
	{
		out.elem[i] = this->elem[i] - Matrix1.elem[i];
	}
	std::cout << out;
}

void operator-(Matrix& Matrix2)
{
	for (int i = 0; i < Matrix2.size_col * Matrix1.size_row; i++) Matrix2.elem[i] *= -1;
	Matrix2.output();
}

void Matrix::operator*(double num)
{
	for (int i = 0; i < size_row * size_col; i++) elem[i] *= num;
}

Matrix operator*(Matrix& Matrix2)
{
	if ((size_col == Matrix2.size_row))
	{
		Matrix out;
		out = new double[size_col*size_row];
		for (int i = 0; i < size_row; i++) {
			for (int j = 0; j < size_col; j++) {
				for (int k = 0; k < size_col; k++) {
					out.elem[i * size_col + j] += elem[i * size_col + k] * Matrix2.elem[k * Matrix2.size_col + j];
				}
			}
		}
		out.output();
	}
	return out;
}

std::istream& operator>>(std::istream& input, Matrix& Matrix1)
{
	int size;
	input >> size;
	Matrix1.input(size);
	return input;
}

std::ostream& operator<<(std::ostream& out, const Matrix& Matrix1)
{
	for (int i = 0; i < Matrix1.size_col; i++) {
		for (int j = 0; j < Matrix1.size_row; j++) {
			out << Matrix1.elem[i* Matrix1.size_row + j] << " ";
		}
		out << '\n';
	}
	return out;
}