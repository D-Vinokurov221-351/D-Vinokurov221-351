#pragma once
#include <iostream>
class Matrix
{
private:
	int size_col, size_row;
	double* elem;
public:
	Matrix();
	Matrix(int row, int col);
	Matrix(int row, int col, double* arr);
	Matrix(int size);
	Matrix(int size, double* arr);
	~Matrix();

	void input(int row, int col);
	void input(int row, int col, double* arr);
	void input(int size);
	void input(int size, double* arr);
	void input();
	void output();
	bool sum_matrix(const Matrix& temp);
	bool sum_matrix(const Matrix& temp, int size); 
	void mult_number(int number);
	bool mult_matrix(const Matrix& temp);
	bool mult_matrix(const Matrix& temp, int size);
	double get_elem(int i, int j) ;
	int get_row() ;
	int get_col() ;
	double trase();
	double tr();

	void operator+=(Matrix& Matrix1);
	void operator=(const Matrix& Matrix1);
	void operator+(Matrix& Matrix1);
	void operator-(Matrix& Matrix1);
	void operator*(double k);
	void operator-=(Matrix& Matrix1);
	Matrix operator*(Matrix& Matrix2);

	friend void operator-(Matrix& Matrix2);
	friend std::istream& operator>>(std::istream& input, Matrix& Matrix1);
	friend std::ostream& operator<<(std::ostream& out, const Matrix& Matrix1);
};

