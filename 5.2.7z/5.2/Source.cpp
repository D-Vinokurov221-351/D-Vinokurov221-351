#include "Matrix.h"
#include <iostream>
int main()
{
    int choise;
    int a = 0;
    while (a == 0)
    {
        std::cout << "What do you wanna do?\n1. Input\n2. Input by hand\n3. matr sum with inp col and rows\n4. matr sum\n5. matr mult with col and rows\n6. matr mult\n";
        std::cin >> choise;
        Matrix m1;
        Matrix m2;
        switch (choise)
        {
        case 1:
        {
            int i, j;
            std::cout << "Input colums and rows ";
            std::cin >> i >> j;
            m1.input(i, j); 
        }
        case 2:
        {
            int i, j;
            std::cout << "Input colums and rows ";
            std::cin >> i >> j; 
            double arr[i*j];
            std::cout << "Input matr ";
            for (int k = 0; k < i * j; k++) {
                std::cin >> arr[k];
            }
            m1.input(i, j, arr);
        }
        case 3:
        {
            int i, j;
            std::cout << "Input colums and rows ";
            std::cin >> i >> j;
            double arr[i*j];
            std::cout << "Input matr ";
            for (int k = 0; k < i * j; k++) {
                std::cin >> arr[k];
            }
            Matrix m2(i, j, arr);
            m1.sum_matrix(m2);
            m1.output();
        }
        case 4:
        {
            Matrix m3(m1.get_row(),m1.get_col());
            Matrix m2(m1.sum_matrix(m3));
            m2.output();
        }
        case 5:
        {
            int i, j;
            std::cout << "Input colums and rows ";
            std::cin >> i >> j;
            double arr[i*j];
            std::cout << "Input matr ";
            for (int k = 0; k < i * j; k++) {
                std::cin >> arr[k];
            }
            Matrix m2(i,j,arr);
            m1.mult_matrix(m2);
        }
        case 6:
        {
            Matrix m3(m1.get_row(),m1.get_col());
            Matrix m2(m1.mult_matrix(m3));
            m2.output();
        }
        default:return 0;
        }
    }
}