#pragma once
#include "Circle.h"
#include "Square.h"
class CircleInSq :
    public Circle,  public Square
{
public:
    CircleInSq();
    ~CircleInSq();
    CircleInSq(double _x, double _y, double _rad);
    CircleInSq(double _side, double _x, double _y, int i);
    CircleInSq(double _side, double _x, double _y, double _rad);
    
    void C_Area();
    void C_Perimeter();
    void S_Area();
    void S_Perimeter();
};