#pragma once
class Position
{
public:
	double x, y;

	Position();
	~Position();
	Position(int z);
	Position(double _x, double _y);
	void out();
};