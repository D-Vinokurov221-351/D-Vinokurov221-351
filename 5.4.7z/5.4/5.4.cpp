#include "Square.h"
#include <iostream>

Square::Square ()
{
    
}

Square::~Square ()
{
    this->x = 0;
    this->y = 0;
    this->side = 1;
}

Square::Square (double _x, double _y, double _side)
{
   this->x = _x;
   this->y = _y;
   this->side = _side;
}

Square::Square (double _side)
{
    this->x = 0;
    this->y = 0;
    this->side = _side;
}

void Square::out()
{
   std::cout << "Side is: " << this->side << ", center is: " << this->x << " " << this->y << std::endl;
}

