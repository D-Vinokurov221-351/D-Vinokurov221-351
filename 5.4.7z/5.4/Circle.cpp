#include "Circle.h"
#include <iostream>

Circle::Circle()
{
}

Circle::~Circle()
{
}

Circle::Circle(double _rad)
{
	this->x = 0;
	this->y = 0;
	this->rad = _rad;
}

Circle::Circle(double _x, double _y, double _rad)
{
	this->x = _x;
	this->y = _y;
	this->rad = _rad;
}


void Circle::out()
{
	std::cout << '\n' << this->x << ' ' << this->y << ' ' << this->rad << '\n';
}