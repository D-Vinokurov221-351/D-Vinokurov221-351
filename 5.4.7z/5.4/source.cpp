#include <iostream>
#include "Circle.h"
#include "Position.h"
#include "Square.h"
#include "CircleInSq.h"

int main()
{
    int choise;
    double x, y, side, rad;
    while (1)
    {
        std::cout << "What do you wanna do?\n1. Inp position\n2. Input circle by you\n3. Input radius\n4. Inp square by you\n5. Inp square`s side\n6. Inp Circle in square by radius\n7. Inp Circle in square by side\n8. All perimeters and areas\n9. Esc\n";
        std::cin >> choise;
        switch (choise)
        {
        case 1:
        {
            std::cout << "Input x and y "; 
            std::cin >> x >> y;
            Position a(x, y);
            a.out();
            break;
        }
        case 2:
        {
            std::cout << "Input center and radius "; 
            std::cin >> x >> y >> rad;
            Circle a(x, y, rad);
            a.out();
            break;
        }
        case 3:
        {
            std::cout << "Input radius"; 
            std::cin >> rad;
            Circle a(rad);
            a.out();
            break;
        }
        case 4:
        {
            std::cout << "Input center and side "; 
            std::cin >> x >> y >> side;
            Square a(x, y, side);
            a.out();
            break;
        }
        case 5:
        {
            std::cout << "Input side "; 
            std::cin >> side;
            Square a(side);
            a.out();
            break;
        }
        case 6:
        {
            std::cout << "Input center and radius "; 
            std::cin >> x >> y >> rad;
            CircleInSq a(x, y, rad);
            a.Circle::out();
            a.Square::out();
            break;
        }
        case 7:
        {
            std::cout << "Input center and side "; 
            std::cin >> x >> y >> side;
            CircleInSq a(side, x , y, 1);
            a.Circle::out();
            a.Square::out();
            break;
        }
        case 8:
        {
            std::cout << "Input center and radius and side"; 
            std::cin >> x >> y >> rad >> side;
            CircleInSq a(side, x, y, rad);
            a.C_Perimeter();
            a.C_Area();
            a.S_Perimeter();
            a.S_Area();
            break;
        }
        case 9: return 0;
        default: break;
        }
    }
}