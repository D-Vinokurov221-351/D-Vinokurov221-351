#include "Position.h"
#include <iostream>
#include <random>

Position::Position()
{
    this->x = 0;
    this->y = 0;
}

Position::~Position()
{
}

Position::Position(int z)
{
	this->x = z;
	this->y = z;
}

Position::Position(double _x, double _y)
{
	this->x = _x;
	this->y = _y;
}

void Position::out()
{
	std::cout << this->x << ' ' << this->y << '\n';
}