#pragma once
#include "Position.h"
class Circle :
    virtual public Position
{
public:
    double rad;
     
    Circle();
    ~Circle();
    Circle(double _rad);
    Circle(double _x, double _y, double _rad);
    void out();
};