#pragma once
#include "Position.h"
class Square:
    virtual public Position
{
public:
    double side;
    
    Square();
    ~Square();
    Square(double _x, double _y, double _side);
    Square(double _side);
    void out();
};