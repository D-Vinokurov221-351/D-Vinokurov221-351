#include "CircleInSq.h"
#include <iostream>

CircleInSq::CircleInSq()
{
}

CircleInSq::~CircleInSq()
{
}

CircleInSq::CircleInSq(double _x, double _y, double _rad)
{
	this->x = _x;
	this->y = _y;
	this->rad = _rad;
}

CircleInSq::CircleInSq(double _side, double _x, double _y, int i)
{
	this->x = _x;
	this->y = _y;
	this->side = _side;
}

CircleInSq::CircleInSq(double _side, double _x, double _y, double _rad)
{
	this->x = _x;
	this->y = _y;
	this->side = _side;
	this->rad = _rad;
}


void CircleInSq::C_Area()
{
    std::cout << "Circle area = " << rad * rad * 3.14 << std::endl;
}

void CircleInSq::C_Perimeter()
{
    std::cout << "Circle perimeter = " << rad * 6.28 << std::endl;
}

void CircleInSq::S_Area()
{
    std::cout << "Square area = " << side * side << std::endl;
}

void CircleInSq::S_Perimeter()
{
    std::cout << "Square perimeter = " << side * 4 << std::endl;
}
