#include "Matrix.h"
#include <iostream>
int main()
{
    int choise;
    int a = 0;
    Matrix matr1;
    Matrix matr2;
    while (a == 0)
    {
        std::cout << "What do you wanna do?\n1. Input\n2. Output\n3. Matr sum\n4. Matr mult\n5. Matr trace\n6. Mult by num\n7. Get rows\n8. Get cols\n9. elem(i,j)\n";
        std::cin >> choise;
        int i, j;
        switch (choise)
        {
        case 1:
            std::cout << "Input rows and colums ";
            std::cin >> i >> j;
            std::cout << "Input matr ";
            matr1.input(i, j);
            break;
        case 2:
            matr1.output();
            break;
        case 3:
            std::cout << "Input rows and colums ";
            std::cin >> i >> j;
            std::cout << '\n' << "Input matr ";
            matr2.input(i, j);
            matr1.sum_matrix(matr2);
            matr1.output();
            break;
        case 4:
            std::cout << "Input rows and colums ";
            std::cin >> i >> j;
            std::cout << "Input matr ";
            matr2.input(i, j);
            matr1.mult_matrix(matr2);
            break;
        case 5:
            matr1.trace();
            break;
        case 6:
            std::cout << "Input num ";
            std::cin >> i;
            matr1.mult_number(i);
            break;
        case 7:
            std::cout << matr1.get_col() << '\n';
            break;
        case 8:
            std::cout << matr1.get_row()<< '\n';
            break;
        case 9:
            std::cout << "Input i and j ";
            std::cin >> i >> j;
            std::cout << matr1.get_elem(i,j) << '\n';
            break;
        default:
            break;
        }
    }
}